<section class="l-section wpb_row height_medium color_footer-top" id="section-01"><div class="l-section-h i-cf"><div class="g-cols vc_row via_grid cols_1 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_top type_default stacking_default"><div class="wpb_column vc_column_container"><div class="vc_column-inner"><div class="wpb_text_column"><div class="wpb_wrapper"></p>
<p style="text-align: center;">© <a href="#">Impreza Theme</a> by UpSolution. <a href="#">Terms and Conditions</a></p>
<p>
</div></div></div></div></div></div></section>
<style></style>